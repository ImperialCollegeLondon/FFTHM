#pragma once

#include <opm/input/eclipse/Deck/Deck.hpp>
#include <opm/input/eclipse/Deck/DeckView.hpp>
#include <opm/input/eclipse/Deck/DeckKeyword.hpp>
#include <opm/input/eclipse/Deck/DeckRecord.hpp>
#include <opm/input/eclipse/Deck/DeckItem.hpp>

struct SphystConfig {
    double alphaSP = 0.0;
    double betaSP  = 0.0;
    double gammaSP = 0.0;
    double shiftSP = 0.0;
    bool   present = false;
};

inline SphystConfig readSphyst(const Opm::Deck& deck)
{
    SphystConfig cfg;

    // If the keyword is not present, just return defaults.
    if (!deck.hasKeyword("SPHYST"))
        return cfg;

    // Deck -> DeckView of the keyword
    const auto& kwView = deck["SPHYST"];   // DeckView<DeckKeyword>

    // First occurrence of SPHYST
    const auto& kw = kwView[0];            // DeckKeyword

    // First record of that keyword
    const auto& rec = kw.getRecord(0);     // DeckRecord

    // Items 0..3 correspond to AlphaSP, BetaSP, GammaSP, ShiftSP.
    // In this OPM version, DeckItem exposes getSIDouble(0) for DOUBLE values.
    cfg.alphaSP = rec.getItem(0).getSIDouble(0);  // 0 ≤ AlphaSP ≤ 1
    cfg.betaSP  = rec.getItem(1).getSIDouble(0);  // BetaSP ≥ 0
    cfg.gammaSP = rec.getItem(2).getSIDouble(0);  // -2 ≤ GammaSP ≤ 3
    cfg.shiftSP = rec.getItem(3).getSIDouble(0);  // ShiftSP ≥ 0

    cfg.present = true;
    return cfg;
}

